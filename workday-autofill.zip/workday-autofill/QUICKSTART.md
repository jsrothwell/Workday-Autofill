# Quick Start Guide

## Installation (2 minutes)

1. **Extract the files** to a folder on your computer

2. **Open Chrome/Brave** and go to:
   - Chrome: `chrome://extensions/`
   - Brave: `brave://extensions/`

3. **Enable Developer Mode**
   - Toggle the switch in the top-right corner

4. **Load the Extension**
   - Click "Load unpacked"
   - Select the `workday-autofill` folder
   - ✅ Done!

## First Use (3 minutes)

1. **Click the extension icon** in your toolbar (pin it for easy access)

2. **Upload your resume**
   - Click "Click to upload or drag & drop"
   - Choose your resume file
   - For best results, use `sample-resume.txt` as a template

3. **Review the parsed data**
   - Check that your information was extracted correctly
   - Click "Edit Data" if you need to make corrections

4. **Navigate to a Workday job application**
   - Example: any URL with "myworkdayjobs.com" or "workday.com"

5. **Click "Fill Workday Form"**
   - The extension will populate the form fields
   - Review and submit!

## Tips

- ✅ **Always review** filled data before submitting
- 💡 **Use TXT format** for best parsing results
- 📝 **Edit data** if something doesn't look right
- 🔄 **Clear data** to start over with a new resume

## Need Help?

Check the full README.md for detailed instructions and troubleshooting.

Happy job hunting! 🚀
