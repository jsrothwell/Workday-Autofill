// Content script that runs on Workday pages
console.log('Workday Auto-Fill: Content script loaded');

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fillForm') {
    fillWorkdayForm(request.data);
    sendResponse({ success: true });
  }
  return true;
});

function fillWorkdayForm(data) {
  console.log('Filling Workday form with data:', data);
  
  // Wait for form to be fully loaded
  setTimeout(() => {
    fillPersonalInfo(data.personalInfo);
    fillExperience(data.experience);
    fillEducation(data.education);
    fillSkills(data.skills);
    
    // Notify user
    showNotification('Form filled successfully! Please review and submit.');
  }, 1000);
}

function fillPersonalInfo(personalInfo) {
  if (!personalInfo) return;
  
  // Common Workday field patterns
  const fieldMappings = {
    // Name fields
    firstName: ['firstname', 'first name', 'given name', 'fname'],
    lastName: ['lastname', 'last name', 'surname', 'family name', 'lname'],
    fullName: ['full name', 'name', 'legal name'],
    
    // Contact fields
    email: ['email', 'e-mail', 'email address'],
    phone: ['phone', 'telephone', 'mobile', 'phone number', 'contact number'],
    
    // Other fields
    linkedIn: ['linkedin', 'linkedin url', 'linkedin profile'],
    address: ['address', 'street address', 'mailing address'],
    city: ['city'],
    state: ['state', 'province'],
    zipCode: ['zip', 'postal code', 'zip code'],
    country: ['country']
  };
  
  // Fill each field
  for (const [key, patterns] of Object.entries(fieldMappings)) {
    if (personalInfo[key]) {
      fillFieldByPatterns(patterns, personalInfo[key]);
    }
  }
  
  // Special handling for address parsing
  if (personalInfo.address && !personalInfo.city) {
    const addressParts = parseAddress(personalInfo.address);
    if (addressParts.city) fillFieldByPatterns(['city'], addressParts.city);
    if (addressParts.state) fillFieldByPatterns(['state', 'province'], addressParts.state);
    if (addressParts.zip) fillFieldByPatterns(['zip', 'postal code'], addressParts.zip);
  }
}

function parseAddress(address) {
  const parts = {};
  
  // Try to extract city, state, zip from address
  // Format: "123 Main St, Springfield, IL 62701"
  const match = address.match(/,\s*([^,]+),\s*([A-Z]{2})\s+(\d{5})/);
  if (match) {
    parts.city = match[1];
    parts.state = match[2];
    parts.zip = match[3];
  }
  
  return parts;
}

function fillExperience(experiences) {
  if (!experiences || experiences.length === 0) return;
  
  // Look for "Add" or "+" buttons for experience
  const addButtons = findAddButtons(['experience', 'work history', 'employment']);
  
  experiences.forEach((exp, index) => {
    // Click add button for each experience after the first
    if (index > 0 && addButtons.length > 0) {
      addButtons[0].click();
      // Wait for new fields to appear
      setTimeout(() => fillSingleExperience(exp, index), 500);
    } else {
      fillSingleExperience(exp, index);
    }
  });
}

function fillSingleExperience(exp, index = 0) {
  const prefix = index > 0 ? `[${index}]` : '';
  
  if (exp.title) {
    fillFieldByPatterns(
      ['job title', 'position', 'title', 'role'],
      exp.title,
      prefix
    );
  }
  
  if (exp.company) {
    fillFieldByPatterns(
      ['company', 'employer', 'organization'],
      exp.company,
      prefix
    );
  }
  
  if (exp.duration) {
    // Try to parse dates
    const dates = parseDuration(exp.duration);
    if (dates.start) {
      fillFieldByPatterns(['start date', 'from date', 'begin date'], dates.start, prefix);
    }
    if (dates.end) {
      fillFieldByPatterns(['end date', 'to date', 'until'], dates.end, prefix);
    }
    if (dates.current) {
      // Check "Currently working here" checkbox
      checkBoxByPatterns(['current', 'present', 'currently working']);
    }
  }
  
  if (exp.description) {
    fillFieldByPatterns(
      ['description', 'responsibilities', 'duties', 'job description'],
      exp.description,
      prefix
    );
  }
}

function fillEducation(education) {
  if (!education || education.length === 0) return;
  
  const addButtons = findAddButtons(['education', 'academic']);
  
  education.forEach((edu, index) => {
    if (index > 0 && addButtons.length > 0) {
      addButtons[0].click();
      setTimeout(() => fillSingleEducation(edu, index), 500);
    } else {
      fillSingleEducation(edu, index);
    }
  });
}

function fillSingleEducation(edu, index = 0) {
  const prefix = index > 0 ? `[${index}]` : '';
  
  if (edu.school) {
    fillFieldByPatterns(
      ['school', 'university', 'college', 'institution'],
      edu.school,
      prefix
    );
  }
  
  if (edu.degree) {
    fillFieldByPatterns(
      ['degree', 'qualification', 'program'],
      edu.degree,
      prefix
    );
  }
  
  if (edu.year) {
    fillFieldByPatterns(
      ['graduation date', 'graduation year', 'year', 'completion date'],
      edu.year,
      prefix
    );
  }
  
  if (edu.gpa) {
    fillFieldByPatterns(['gpa', 'grade point average'], edu.gpa, prefix);
  }
}

function fillSkills(skills) {
  if (!skills || skills.length === 0) return;
  
  const skillsText = skills.join(', ');
  fillFieldByPatterns(
    ['skills', 'technical skills', 'competencies', 'expertise'],
    skillsText
  );
}

function fillFieldByPatterns(patterns, value, prefix = '') {
  // Try to find and fill input fields matching the patterns
  const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], textarea');
  
  for (const input of inputs) {
    const label = findLabelForInput(input);
    const placeholder = input.placeholder?.toLowerCase() || '';
    const name = input.name?.toLowerCase() || '';
    const id = input.id?.toLowerCase() || '';
    const ariaLabel = input.getAttribute('aria-label')?.toLowerCase() || '';
    
    const searchText = `${label} ${placeholder} ${name} ${id} ${ariaLabel}`.toLowerCase();
    
    for (const pattern of patterns) {
      if (searchText.includes(pattern.toLowerCase())) {
        setInputValue(input, value);
        return true;
      }
    }
  }
  
  return false;
}

function findLabelForInput(input) {
  // Try to find associated label
  if (input.id) {
    const label = document.querySelector(`label[for="${input.id}"]`);
    if (label) return label.textContent.toLowerCase();
  }
  
  // Look for parent label
  const parentLabel = input.closest('label');
  if (parentLabel) return parentLabel.textContent.toLowerCase();
  
  // Look for nearby label
  const prevElement = input.previousElementSibling;
  if (prevElement && prevElement.tagName === 'LABEL') {
    return prevElement.textContent.toLowerCase();
  }
  
  // Look for aria-labelledby
  const ariaLabelledBy = input.getAttribute('aria-labelledby');
  if (ariaLabelledBy) {
    const labelElement = document.getElementById(ariaLabelledBy);
    if (labelElement) return labelElement.textContent.toLowerCase();
  }
  
  return '';
}

function setInputValue(input, value) {
  // Set value and trigger events to ensure form validation works
  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype,
    'value'
  ).set;
  
  nativeInputValueSetter.call(input, value);
  
  // Trigger events
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new Event('blur', { bubbles: true }));
  
  console.log(`Filled field: ${input.name || input.id} with value: ${value}`);
}

function findAddButtons(sectionPatterns) {
  const buttons = document.querySelectorAll('button, a');
  const addButtons = [];
  
  for (const button of buttons) {
    const text = button.textContent.toLowerCase();
    const ariaLabel = button.getAttribute('aria-label')?.toLowerCase() || '';
    
    if (text.includes('add') || text.includes('+') || ariaLabel.includes('add')) {
      // Check if it's related to our section
      for (const pattern of sectionPatterns) {
        if (text.includes(pattern) || ariaLabel.includes(pattern)) {
          addButtons.push(button);
          break;
        }
      }
    }
  }
  
  return addButtons;
}

function checkBoxByPatterns(patterns) {
  const checkboxes = document.querySelectorAll('input[type="checkbox"]');
  
  for (const checkbox of checkboxes) {
    const label = findLabelForInput(checkbox);
    
    for (const pattern of patterns) {
      if (label.includes(pattern.toLowerCase())) {
        if (!checkbox.checked) {
          checkbox.click();
        }
        return true;
      }
    }
  }
  
  return false;
}

function parseDuration(duration) {
  const dates = {
    start: '',
    end: '',
    current: false
  };
  
  // Handle "Present" or "Current"
  if (duration.toLowerCase().includes('present') || duration.toLowerCase().includes('current')) {
    dates.current = true;
  }
  
  // Try to extract dates
  // Format: "Jan 2020 - Dec 2023" or "2020 - 2023"
  const parts = duration.split(/[-–—]/);
  
  if (parts.length >= 2) {
    dates.start = parts[0].trim();
    if (!dates.current) {
      dates.end = parts[1].trim();
    }
  }
  
  return dates;
}

function showNotification(message) {
  // Create a notification div
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 16px 24px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 500;
    animation: slideIn 0.3s ease-out;
  `;
  notification.textContent = message;
  
  // Add animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from {
        transform: translateX(400px);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
  `;
  document.head.appendChild(style);
  
  document.body.appendChild(notification);
  
  // Remove after 5 seconds
  setTimeout(() => {
    notification.style.animation = 'slideIn 0.3s ease-out reverse';
    setTimeout(() => notification.remove(), 300);
  }, 5000);
}

// Auto-detect if we're on a Workday application page
if (window.location.href.includes('workday')) {
  console.log('Workday Auto-Fill: Ready to fill forms');
}
