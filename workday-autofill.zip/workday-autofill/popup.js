// DOM elements
const resumeInput = document.getElementById('resume-input');
const uploadArea = document.getElementById('upload-area');
const fileInfo = document.getElementById('file-info');
const uploadSection = document.getElementById('upload-section');
const statusSection = document.getElementById('status-section');
const actionSection = document.getElementById('action-section');
const resumePreview = document.getElementById('resume-preview');
const fillFormBtn = document.getElementById('fill-form-btn');
const statusMessage = document.getElementById('status-message');
const clearDataBtn = document.getElementById('clear-data-btn');
const editDataBtn = document.getElementById('edit-data-btn');
const editModal = document.getElementById('edit-modal');
const editForm = document.getElementById('edit-form');
const saveEditBtn = document.getElementById('save-edit-btn');
const cancelEditBtn = document.getElementById('cancel-edit-btn');

let parsedResumeData = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadSavedData();
  setupEventListeners();
});

function setupEventListeners() {
  // File input
  resumeInput.addEventListener('change', handleFileSelect);
  
  // Drag and drop
  uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('drag-over');
  });
  
  uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('drag-over');
  });
  
  uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.classList.remove('drag-over');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFile(files[0]);
    }
  });
  
  // Buttons
  fillFormBtn.addEventListener('click', fillWorkdayForm);
  clearDataBtn.addEventListener('click', clearSavedData);
  editDataBtn.addEventListener('click', showEditModal);
  saveEditBtn.addEventListener('click', saveEditedData);
  cancelEditBtn.addEventListener('click', hideEditModal);
}

async function loadSavedData() {
  const result = await chrome.storage.local.get(['resumeData']);
  if (result.resumeData) {
    parsedResumeData = result.resumeData;
    displayResumeData(parsedResumeData);
  }
}

function handleFileSelect(event) {
  const file = event.target.files[0];
  if (file) {
    handleFile(file);
  }
}

async function handleFile(file) {
  const validTypes = ['application/pdf', 'application/msword', 
                      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                      'text/plain'];
  
  if (!validTypes.includes(file.type) && !file.name.match(/\.(pdf|doc|docx|txt)$/i)) {
    showStatus('Please upload a PDF, DOC, DOCX, or TXT file', 'error');
    return;
  }
  
  fileInfo.textContent = `Selected: ${file.name}`;
  fileInfo.classList.remove('hidden');
  
  showStatus('Processing resume...', 'info');
  
  try {
    const text = await extractTextFromFile(file);
    parsedResumeData = parseResumeText(text);
    
    await chrome.storage.local.set({ resumeData: parsedResumeData });
    
    displayResumeData(parsedResumeData);
    showStatus('Resume processed successfully!', 'success');
  } catch (error) {
    console.error('Error processing file:', error);
    showStatus('Error processing resume. Please try again.', 'error');
  }
}

async function extractTextFromFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      const content = e.target.result;
      
      if (file.type === 'text/plain') {
        resolve(content);
      } else if (file.type === 'application/pdf') {
        // For PDF, we'll get base64 and try to extract text
        // In a real implementation, you'd use pdf.js here
        // For now, we'll prompt the user to use a text version
        resolve(content);
      } else {
        // For DOC/DOCX, similar limitation
        resolve(content);
      }
    };
    
    reader.onerror = reject;
    
    if (file.type === 'text/plain') {
      reader.readAsText(file);
    } else {
      reader.readAsText(file); // Simplified for demo
    }
  });
}

function parseResumeText(text) {
  // Basic resume parsing logic
  // In production, you'd want a more sophisticated parser or use an API
  
  const data = {
    personalInfo: {},
    experience: [],
    education: [],
    skills: []
  };
  
  // Extract email
  const emailMatch = text.match(/[\w.-]+@[\w.-]+\.\w+/);
  if (emailMatch) {
    data.personalInfo.email = emailMatch[0];
  }
  
  // Extract phone
  const phoneMatch = text.match(/(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
  if (phoneMatch) {
    data.personalInfo.phone = phoneMatch[0];
  }
  
  // Extract name (first line usually)
  const lines = text.split('\n').filter(line => line.trim());
  if (lines.length > 0) {
    const firstLine = lines[0].trim();
    if (firstLine.length < 50 && !firstLine.includes('@')) {
      data.personalInfo.fullName = firstLine;
      
      // Split into first and last name
      const nameParts = firstLine.split(' ');
      if (nameParts.length >= 2) {
        data.personalInfo.firstName = nameParts[0];
        data.personalInfo.lastName = nameParts[nameParts.length - 1];
      }
    }
  }
  
  // Extract LinkedIn
  const linkedInMatch = text.match(/linkedin\.com\/in\/[\w-]+/i);
  if (linkedInMatch) {
    data.personalInfo.linkedIn = 'https://' + linkedInMatch[0];
  }
  
  // Look for address
  const addressMatch = text.match(/\d+\s+[\w\s,]+,\s*[A-Z]{2}\s+\d{5}/);
  if (addressMatch) {
    data.personalInfo.address = addressMatch[0];
  }
  
  // Parse experience section
  const experienceSection = extractSection(text, ['experience', 'work history', 'employment']);
  if (experienceSection) {
    data.experience = parseExperienceSection(experienceSection);
  }
  
  // Parse education section
  const educationSection = extractSection(text, ['education', 'academic']);
  if (educationSection) {
    data.education = parseEducationSection(educationSection);
  }
  
  // Parse skills
  const skillsSection = extractSection(text, ['skills', 'technical skills', 'competencies']);
  if (skillsSection) {
    data.skills = parseSkillsSection(skillsSection);
  }
  
  return data;
}

function extractSection(text, keywords) {
  const lowerText = text.toLowerCase();
  
  for (const keyword of keywords) {
    const index = lowerText.indexOf(keyword);
    if (index !== -1) {
      // Find the next section or end of text
      const nextSectionKeywords = ['experience', 'education', 'skills', 'projects', 'certifications', 'awards'];
      let endIndex = text.length;
      
      for (const nextKeyword of nextSectionKeywords) {
        const nextIndex = lowerText.indexOf(nextKeyword, index + keyword.length);
        if (nextIndex !== -1 && nextIndex < endIndex) {
          endIndex = nextIndex;
        }
      }
      
      return text.substring(index, endIndex);
    }
  }
  
  return null;
}

function parseExperienceSection(section) {
  const experiences = [];
  const lines = section.split('\n').filter(line => line.trim());
  
  let currentExp = null;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Look for date patterns (e.g., "2020 - 2023", "Jan 2020 - Present")
    const datePattern = /(\d{4}|\w{3,9}\s+\d{4})\s*[-–—]\s*(\d{4}|\w{3,9}\s+\d{4}|Present|Current)/i;
    const dateMatch = line.match(datePattern);
    
    if (dateMatch || (line.includes('|') || line.includes('–') || line.includes('—'))) {
      if (currentExp) {
        experiences.push(currentExp);
      }
      
      currentExp = {
        title: '',
        company: '',
        duration: dateMatch ? dateMatch[0] : '',
        description: ''
      };
      
      // Try to extract company and title
      const parts = line.split(/[|–—]/);
      if (parts.length >= 2) {
        currentExp.title = parts[0].replace(dateMatch ? dateMatch[0] : '', '').trim();
        currentExp.company = parts[1].trim();
      } else {
        currentExp.title = line.replace(dateMatch ? dateMatch[0] : '', '').trim();
      }
    } else if (currentExp && line.startsWith('•') || line.startsWith('-') || line.startsWith('*')) {
      currentExp.description += (currentExp.description ? '\n' : '') + line;
    }
  }
  
  if (currentExp) {
    experiences.push(currentExp);
  }
  
  return experiences;
}

function parseEducationSection(section) {
  const education = [];
  const lines = section.split('\n').filter(line => line.trim());
  
  let currentEdu = null;
  
  for (const line of lines) {
    const trimmedLine = line.trim();
    
    // Look for degree patterns
    const degreePattern = /(bachelor|master|phd|ph\.d|associate|b\.s\.|m\.s\.|b\.a\.|m\.a\.|mba)/i;
    const datePattern = /\d{4}/;
    
    if (degreePattern.test(trimmedLine) || datePattern.test(trimmedLine)) {
      if (currentEdu) {
        education.push(currentEdu);
      }
      
      currentEdu = {
        degree: '',
        school: '',
        year: '',
        gpa: ''
      };
      
      const yearMatch = trimmedLine.match(/\d{4}/);
      if (yearMatch) {
        currentEdu.year = yearMatch[0];
      }
      
      if (degreePattern.test(trimmedLine)) {
        currentEdu.degree = trimmedLine.replace(/\d{4}/g, '').trim();
      }
    } else if (currentEdu && trimmedLine.length > 0) {
      if (!currentEdu.school) {
        currentEdu.school = trimmedLine;
      }
      
      // Look for GPA
      const gpaMatch = trimmedLine.match(/gpa:?\s*([\d.]+)/i);
      if (gpaMatch) {
        currentEdu.gpa = gpaMatch[1];
      }
    }
  }
  
  if (currentEdu) {
    education.push(currentEdu);
  }
  
  return education;
}

function parseSkillsSection(section) {
  const skills = [];
  const lines = section.split('\n').filter(line => line.trim());
  
  for (const line of lines) {
    const trimmedLine = line.trim();
    if (trimmedLine && !trimmedLine.toLowerCase().includes('skills')) {
      // Split by common delimiters
      const lineSkills = trimmedLine.split(/[,;|•\-\*]/).map(s => s.trim()).filter(s => s);
      skills.push(...lineSkills);
    }
  }
  
  return skills;
}

function displayResumeData(data) {
  statusSection.classList.remove('hidden');
  actionSection.classList.remove('hidden');
  
  let html = '';
  
  // Personal Info
  if (data.personalInfo && Object.keys(data.personalInfo).length > 0) {
    html += '<div class="preview-section">';
    html += '<div class="preview-label">Personal Information</div>';
    if (data.personalInfo.fullName) html += `<div class="preview-value">Name: ${data.personalInfo.fullName}</div>`;
    if (data.personalInfo.email) html += `<div class="preview-value">Email: ${data.personalInfo.email}</div>`;
    if (data.personalInfo.phone) html += `<div class="preview-value">Phone: ${data.personalInfo.phone}</div>`;
    if (data.personalInfo.linkedIn) html += `<div class="preview-value">LinkedIn: ${data.personalInfo.linkedIn}</div>`;
    if (data.personalInfo.address) html += `<div class="preview-value">Address: ${data.personalInfo.address}</div>`;
    html += '</div>';
  }
  
  // Experience
  if (data.experience && data.experience.length > 0) {
    html += '<div class="preview-section">';
    html += '<div class="preview-label">Experience</div>';
    html += '<div class="preview-list">';
    data.experience.forEach(exp => {
      html += '<div class="preview-list-item">';
      if (exp.title) html += `<div><strong>${exp.title}</strong></div>`;
      if (exp.company) html += `<div>${exp.company}</div>`;
      if (exp.duration) html += `<div style="font-size: 12px; color: #999;">${exp.duration}</div>`;
      html += '</div>';
    });
    html += '</div></div>';
  }
  
  // Education
  if (data.education && data.education.length > 0) {
    html += '<div class="preview-section">';
    html += '<div class="preview-label">Education</div>';
    html += '<div class="preview-list">';
    data.education.forEach(edu => {
      html += '<div class="preview-list-item">';
      if (edu.degree) html += `<div><strong>${edu.degree}</strong></div>`;
      if (edu.school) html += `<div>${edu.school}</div>`;
      if (edu.year) html += `<div style="font-size: 12px; color: #999;">${edu.year}</div>`;
      html += '</div>';
    });
    html += '</div></div>';
  }
  
  // Skills
  if (data.skills && data.skills.length > 0) {
    html += '<div class="preview-section">';
    html += '<div class="preview-label">Skills</div>';
    html += `<div class="preview-value">${data.skills.join(', ')}</div>`;
    html += '</div>';
  }
  
  resumePreview.innerHTML = html;
}

function showEditModal() {
  if (!parsedResumeData) return;
  
  let formHtml = '';
  
  // Personal Info fields
  formHtml += '<h3 style="margin-bottom: 10px; font-size: 14px;">Personal Information</h3>';
  formHtml += createFormField('firstName', 'First Name', parsedResumeData.personalInfo.firstName || '');
  formHtml += createFormField('lastName', 'Last Name', parsedResumeData.personalInfo.lastName || '');
  formHtml += createFormField('email', 'Email', parsedResumeData.personalInfo.email || '');
  formHtml += createFormField('phone', 'Phone', parsedResumeData.personalInfo.phone || '');
  formHtml += createFormField('linkedIn', 'LinkedIn URL', parsedResumeData.personalInfo.linkedIn || '');
  formHtml += createFormField('address', 'Address', parsedResumeData.personalInfo.address || '');
  
  editForm.innerHTML = formHtml;
  editModal.classList.remove('hidden');
}

function createFormField(name, label, value) {
  return `
    <div class="form-group">
      <label for="edit-${name}">${label}</label>
      <input type="text" id="edit-${name}" value="${value}" />
    </div>
  `;
}

function hideEditModal() {
  editModal.classList.add('hidden');
}

async function saveEditedData() {
  parsedResumeData.personalInfo.firstName = document.getElementById('edit-firstName').value;
  parsedResumeData.personalInfo.lastName = document.getElementById('edit-lastName').value;
  parsedResumeData.personalInfo.email = document.getElementById('edit-email').value;
  parsedResumeData.personalInfo.phone = document.getElementById('edit-phone').value;
  parsedResumeData.personalInfo.linkedIn = document.getElementById('edit-linkedIn').value;
  parsedResumeData.personalInfo.address = document.getElementById('edit-address').value;
  
  // Update full name
  if (parsedResumeData.personalInfo.firstName && parsedResumeData.personalInfo.lastName) {
    parsedResumeData.personalInfo.fullName = 
      `${parsedResumeData.personalInfo.firstName} ${parsedResumeData.personalInfo.lastName}`;
  }
  
  await chrome.storage.local.set({ resumeData: parsedResumeData });
  displayResumeData(parsedResumeData);
  hideEditModal();
  showStatus('Data updated successfully!', 'success');
}

async function fillWorkdayForm() {
  if (!parsedResumeData) {
    showStatus('Please upload a resume first', 'error');
    return;
  }
  
  showStatus('Filling form...', 'info');
  
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab.url.includes('workday')) {
      showStatus('Please navigate to a Workday application page', 'error');
      return;
    }
    
    await chrome.tabs.sendMessage(tab.id, {
      action: 'fillForm',
      data: parsedResumeData
    });
    
    showStatus('Form filled successfully!', 'success');
  } catch (error) {
    console.error('Error filling form:', error);
    showStatus('Error filling form. Make sure you\'re on a Workday page.', 'error');
  }
}

async function clearSavedData() {
  if (confirm('Are you sure you want to clear your saved resume data?')) {
    await chrome.storage.local.remove(['resumeData']);
    parsedResumeData = null;
    
    fileInfo.classList.add('hidden');
    statusSection.classList.add('hidden');
    actionSection.classList.add('hidden');
    resumeInput.value = '';
    
    showStatus('Data cleared', 'info');
  }
}

function showStatus(message, type) {
  statusMessage.textContent = message;
  statusMessage.className = `status-message ${type}`;
  statusMessage.style.display = 'block';
  
  if (type === 'success' || type === 'error') {
    setTimeout(() => {
      statusMessage.style.display = 'none';
    }, 5000);
  }
}
