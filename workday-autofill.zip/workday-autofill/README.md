# Workday Auto-Fill Assistant

A Chrome/Brave browser extension that automatically fills Workday job applications using data from your resume. Save time and reduce the frustration of re-entering the same information repeatedly!

## Features

- 📄 **Resume Upload**: Upload your resume in PDF, DOC, DOCX, or TXT format
- 🤖 **Smart Parsing**: Automatically extracts personal information, work experience, education, and skills
- ✏️ **Editable Data**: Review and edit parsed information before filling forms
- 🎯 **Auto-Fill**: One-click form filling on Workday application pages
- 💾 **Data Persistence**: Your resume data is saved locally for reuse
- 🔒 **Privacy First**: All data stays in your browser - nothing is sent to external servers

## Installation

### Method 1: Load Unpacked Extension (Developer Mode)

1. **Download the Extension**
   - Download all files or clone this repository
   - Keep all files in the `workday-autofill` folder

2. **Open Chrome/Brave Extensions Page**
   - Navigate to `chrome://extensions/` (Chrome) or `brave://extensions/` (Brave)
   - Or click Menu → More Tools → Extensions

3. **Enable Developer Mode**
   - Toggle the "Developer mode" switch in the top-right corner

4. **Load the Extension**
   - Click "Load unpacked"
   - Select the `workday-autofill` folder
   - The extension should now appear in your extensions list

5. **Pin the Extension** (Optional)
   - Click the puzzle piece icon in your browser toolbar
   - Find "Workday Auto-Fill Assistant" and click the pin icon

## Usage

### 1. Upload Your Resume

1. Click the extension icon in your browser toolbar
2. Click "Click to upload or drag & drop" in the popup
3. Select your resume file (PDF, DOC, DOCX, or TXT)
4. Wait for the extension to parse your resume

### 2. Review and Edit Data

1. After parsing, review the extracted information
2. Click "Edit Data" to make any corrections
3. Update fields as needed and click "Save Changes"

### 3. Fill Workday Forms

1. Navigate to a Workday job application page
2. Click the extension icon
3. Click "Fill Workday Form"
4. The extension will automatically populate the form fields
5. **Always review** the filled data before submitting!

## Supported Resume Formats

- **PDF**: Text-based PDFs work best (not scanned images)
- **DOCX**: Microsoft Word documents
- **DOC**: Older Word documents
- **TXT**: Plain text files

### Tips for Best Results

- Use a standard resume format with clear sections (Experience, Education, Skills)
- Include clear section headers like "Experience", "Education", "Skills"
- Format dates consistently (e.g., "Jan 2020 - Dec 2023" or "2020 - 2023")
- Use bullet points for job responsibilities
- For best parsing, consider using a TXT version of your resume

## How It Works

1. **Resume Parsing**: The extension uses pattern matching to extract:
   - Personal information (name, email, phone, LinkedIn, address)
   - Work experience (job titles, companies, dates, descriptions)
   - Education (degrees, schools, graduation years, GPA)
   - Skills and competencies

2. **Field Matching**: When filling forms, the extension:
   - Identifies form fields by their labels, placeholders, and attributes
   - Matches extracted data to the appropriate fields
   - Handles various Workday form variations

3. **Data Storage**: Your resume data is stored locally using Chrome's storage API:
   - Data never leaves your browser
   - Accessible only by this extension
   - Can be cleared at any time

## Troubleshooting

### Resume Not Parsing Correctly

- **Try TXT format**: Convert your resume to plain text for better parsing
- **Simplify formatting**: Remove complex tables, graphics, or unusual formatting
- **Use standard sections**: Label sections clearly (Experience, Education, Skills)
- **Edit manually**: Use the "Edit Data" feature to correct any issues

### Form Not Filling

- **Check URL**: Make sure you're on a Workday page (URL contains "workday")
- **Wait for page load**: Ensure the form is fully loaded before clicking fill
- **Reload page**: Try refreshing the Workday page and filling again
- **Manual entry**: Some fields may need to be filled manually due to Workday variations

### Extension Not Loading

- **Check Developer Mode**: Ensure Developer mode is enabled
- **Reload Extension**: Go to `chrome://extensions/` and click the reload icon
- **Check Console**: Right-click extension icon → Inspect popup → Check Console for errors

## Privacy & Security

- ✅ All resume data is stored locally in your browser
- ✅ No data is sent to external servers
- ✅ The extension only runs on Workday domains
- ✅ You can clear your data at any time
- ✅ Open source - you can review the code

## Data Management

### Clear Saved Data

- Click the extension icon
- Click "Clear Saved Data" at the bottom
- Confirm deletion

Your resume data will be removed from local storage.

## Known Limitations

- **Workday Variations**: Different companies customize Workday differently; some fields may not auto-fill
- **Complex Forms**: Multi-step wizards or conditional fields may require manual intervention
- **Resume Parsing**: Complex resume formats may not parse perfectly
- **File Types**: Scanned PDFs (images) won't work - they need to be text-based PDFs

## Development

### File Structure

```
workday-autofill/
├── manifest.json          # Extension configuration
├── popup.html            # Extension popup UI
├── popup.css             # Popup styles
├── popup.js              # Popup logic and resume parsing
├── content.js            # Content script for Workday pages
├── background.js         # Background service worker
├── icons/                # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md             # This file
```

### Enhancement Ideas

- [ ] Add support for more file formats (PDF text extraction)
- [ ] Integrate AI (Claude API) for better resume parsing
- [ ] Support for LinkedIn profile import
- [ ] Cover letter management
- [ ] Application tracking
- [ ] Support for other ATS systems (Greenhouse, Lever, etc.)

## Contributing

Feel free to fork, modify, and improve this extension! Some areas that could use enhancement:

1. Better PDF parsing (integration with pdf.js)
2. More robust field detection for Workday variations
3. Support for additional job application platforms
4. Improved UI/UX
5. Better error handling and user feedback

## License

This is free and unencumbered software released into the public domain.

## Disclaimer

This extension is not affiliated with or endorsed by Workday. Always review auto-filled information before submitting job applications. The accuracy of auto-fill depends on resume format and Workday page structure.

## Support

If you encounter issues:

1. Check the Troubleshooting section above
2. Review the browser console for errors (F12 → Console)
3. Try editing your resume data manually
4. As a last resort, fill forms manually while referencing your stored data

---

**Happy job hunting! 🚀**
