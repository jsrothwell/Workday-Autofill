// Background service worker for the extension

chrome.runtime.onInstalled.addListener(() => {
  console.log('Workday Auto-Fill extension installed');
});

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'parseResume') {
    // Handle resume parsing if needed
    parseResume(request.data)
      .then(result => sendResponse({ success: true, data: result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Will respond asynchronously
  }
});

async function parseResume(fileData) {
  // This could be enhanced to use an AI service for better parsing
  // For now, the parsing is handled in popup.js
  return fileData;
}

// Helper to check if we're on a Workday page
function isWorkdayPage(url) {
  return url.includes('myworkdayjobs.com') || url.includes('workday.com');
}

// Update badge when on Workday pages
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    if (isWorkdayPage(tab.url)) {
      chrome.action.setBadgeText({ text: '✓', tabId: tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#4CAF50', tabId: tabId });
    } else {
      chrome.action.setBadgeText({ text: '', tabId: tabId });
    }
  }
});
